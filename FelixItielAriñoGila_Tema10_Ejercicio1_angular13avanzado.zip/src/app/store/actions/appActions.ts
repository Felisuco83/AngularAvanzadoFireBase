// Definimos los tipos de las acciones que vamos a disponer en esta aplicación
// UNA ACCIÓN TENDRÁ:
// -TYPE
// -PAYLOAD
export const ACTION_CAMBIO_MENSAJE = 'ACTION_CAMBIO_MENSAJE';
export const ACTION_CAMBIO_VALOR = 'ACTION_CAMBIO_VALOR';