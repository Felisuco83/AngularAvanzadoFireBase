// Crearemos una interface para asegurar la estructura y tipología de los datos almacenados en el estado de nuestro reducer

export interface IAppReducerState {
    mensaje: string;
    valor: boolean;
}
